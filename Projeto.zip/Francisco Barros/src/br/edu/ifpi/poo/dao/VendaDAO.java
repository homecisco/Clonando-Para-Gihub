package br.edu.ifpi.poo.dao;

public class VendaDAO {
	
}
