package br.edu.ifpi.poo.prova;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import br.edu.ifpi.poo.prova.model.Aluno;

public class AlunoTest {
	private static Aluno a;

	@BeforeClass
	public static void inicializar() {
		a = new Aluno();
	}

	@Test
	public void testValidaNome() {
		a.setNome("Francisco");
		Assert.assertTrue(a.ValidaNome());
	}
}
