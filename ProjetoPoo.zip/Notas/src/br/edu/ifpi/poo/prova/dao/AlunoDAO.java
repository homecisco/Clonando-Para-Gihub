package br.edu.ifpi.poo.prova.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;

import br.edu.ifpi.poo.prova.model.Aluno;

public class AlunoDAO {
	private EntityManager em = Persistence.createEntityManagerFactory(
			"notas-jpa").createEntityManager();

	public void fechar() {
		em.close();
	}

	public void commit() {
		em.getTransaction().commit();
	}

	public void iniciar() {
		em.getTransaction().begin();
	}

	public void salvar(Aluno a) {
		em.persist(a);
	}

	public void apagar(Aluno a) {
		em.remove(a);
	}

	public void atualizar(Aluno a) {
		em.merge(a);
	}

	public Aluno procurar(Long id) {
		return em.find(Aluno.class, id);
	}

	public List<Aluno> listarTodos() {
		Query query = em.createNamedQuery("Aluno.buscarTodos");
		return query.getResultList();
	}
	
	public Aluno procurarPorCpf(String cpf){
		Query query = em.createNamedQuery("Aluno.buscarPorCpf");
		query.setParameter("cpf",cpf);
		return (Aluno) query.getSingleResult();
	}
}
