package br.edu.ifpi.poo.prova.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
@NamedQueries({
		@NamedQuery(name = "Aluno.buscarTodos", query = "SELECT a FROM Aluno a"),
		@NamedQuery(name = "Aluno.buscarPorCpf", query = "SELECT a FROM Aluno a WHERE a.id =: id") })
public class Aluno {
	@Id
	@GeneratedValue
	private Long id;
	private String Nome;
	private Double Nota1;
	private Double Nota2;

	public Aluno() {
		super();
	}

	public Aluno(String nome, Double nota1, Double nota2) {
		super();
		Nome = nome;
		Nota1 = nota1;
		Nota2 = nota2;
	}

	public Aluno(Long id, String nome, Double nota1, Double nota2) {
		super();
		this.id = id;
		Nome = nome;
		Nota1 = nota1;
		Nota2 = nota2;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public Double getNota1() {
		return Nota1;
	}

	public void setNota1(Double nota1) {
		Nota1 = nota1;
	}

	public Double getNota2() {
		return Nota2;
	}

	public void setNota2(Double nota2) {
		Nota2 = nota2;
	}

	public boolean ValidaNome() {
		String regex = "[a-z]*";
		return this.Nome.toLowerCase().matches(regex);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Nome == null) ? 0 : Nome.hashCode());
		result = prime * result + ((Nota1 == null) ? 0 : Nota1.hashCode());
		result = prime * result + ((Nota2 == null) ? 0 : Nota2.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Aluno other = (Aluno) obj;
		if (Nome == null) {
			if (other.Nome != null)
				return false;
		} else if (!Nome.equals(other.Nome))
			return false;
		if (Nota1 == null) {
			if (other.Nota1 != null)
				return false;
		} else if (!Nota1.equals(other.Nota1))
			return false;
		if (Nota2 == null) {
			if (other.Nota2 != null)
				return false;
		} else if (!Nota2.equals(other.Nota2))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Aluno [id=" + id + ", Nome=" + Nome + ", Nota1=" + Nota1
				+ ", Nota2=" + Nota2 + "]";
	}

}
